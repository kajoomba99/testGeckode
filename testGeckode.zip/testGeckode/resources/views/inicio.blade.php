@extends('layout')
@section('content')
<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">
            @isset($confirmacion)
            @if($confirmacion)
                <div class="alert alert-dismissible alert-success">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <strong>Bien hecho!</strong> Tarea agregada correctamente.  
                </div>
            @else
                <div class="alert alert-dismissible alert-danger">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <strong>Oh vaya!</strong> Algo salio mal.
                </div>
            @endif
            @endisset
            <form action="{{route('add_new_task')}}" method="POST">
                @csrf
                <div class="row">
                    <div class="form-group col-md-11">
                        <input type="text" name="task" class="form-control" placeholder="NEW TASK" autocomplete="off">
                    </div>
                    <div class="col-md-1">
                        <button class="btn btn-secondary">ADD</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="row mt-3">
        @foreach ($tareas as $tarea)
        <div class="well col-md-6">
            <form action="{{route('actions')}}" method="POST"> 
                @csrf
                <div class="card text-white {{$tarea->finished==0?'bg-warning':'bg-primary'}} mb-3">
                    <div class="card-header">
                        @if($tarea->finished==0)
                        <input type="text" class="form-control" value="{{strtoupper($tarea->name)}}" name="name">
                        @else
                        {{strtoupper($tarea->name)}}
                        @endif

                        @php
                            $dia = substr($tarea->created, 0, 2);
                            $mes = substr($tarea->created, 3, 2);
                            $año = substr($tarea->created, 6, 4);
                            $mesint = (int)$mes;
                            // return $arreglo[$index];
                        @endphp
                        <p><small>Fecha de creacion: <strong>{{$dia}}/{{$meses[$mesint]}}-{{$año}}</strong></small></p>
                    </div>
                    <div class="card-body">
                        {{-- <h4 class="card-title">Primary card title</h4>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p> --}}
                        <div class="alert alert-dismissible alert-success">
                            <input type="text" class="form-control" value="SUB TAREA" name="name">
                            <button type="button" class="btn">&#10060;</button>
                            <button type="button" class="btn">&#9997;</button>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" value="{{$tarea->id}}" name="id">
                        @if($tarea->finished==0)                    
                        <button type="submit" class="btn btn-sm btn-primary" name="opcion" value="1">COMPLETADA</button>
                        <button type="submit" class="btn btn-sm btn-light" data-dismiss="modal" name="opcion" value="2">EDITAR</button>
                        <button type="submit" class="btn btn-sm btn-secondary" data-dismiss="modal" name="opcion" value="3">ELIMINAR</button>
                        @else
                        <button type="submit" class="btn btn-sm btn-secondary" data-dismiss="modal" name="opcion" value="3">ELIMINAR</button>
                        @endif
                    </div>
                </form>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection