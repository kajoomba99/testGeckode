<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">
            <?php if(isset($confirmacion)): ?>
            <?php if($confirmacion): ?>
                <div class="alert alert-dismissible alert-success">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <strong>Bien hecho!</strong> Tarea agregada correctamente.  
                </div>
            <?php else: ?>
                <div class="alert alert-dismissible alert-danger">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <strong>Oh vaya!</strong> Algo salio mal.
                </div>
            <?php endif; ?>
            <?php endif; ?>
            <form action="<?php echo e(route('add_new_task')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="form-group col-md-11">
                        <input type="text" name="task" class="form-control" placeholder="NEW TASK" autocomplete="off">
                    </div>
                    <div class="col-md-1">
                        <button class="btn btn-secondary">ADD</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="row mt-3">
        <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="well col-md-6">
            <form action="<?php echo e(route('actions')); ?>" method="POST"> 
                <?php echo csrf_field(); ?>
                <div class="card text-white <?php echo e($tarea->finished==0?'bg-warning':'bg-primary'); ?> mb-3">
                    <div class="card-header">
                        <?php if($tarea->finished==0): ?>
                        <input type="text" class="form-control" value="<?php echo e(strtoupper($tarea->name)); ?>" name="name">
                        <?php else: ?>
                        <?php echo e(strtoupper($tarea->name)); ?>

                        <?php endif; ?>

                        <?php
                            $dia = substr($tarea->created, 0, 2);
                            $mes = substr($tarea->created, 3, 2);
                            $año = substr($tarea->created, 6, 4);
                            $mesint = (int)$mes;
                            // return $arreglo[$index];
                        ?>
                        <p><small>Fecha de creacion: <strong><?php echo e($dia); ?>/<?php echo e($meses[$mesint]); ?>-<?php echo e($año); ?></strong></small></p>
                    </div>
                    <div class="card-body">
                        
                        <div class="alert alert-dismissible alert-success">
                            <input type="text" class="form-control" value="SUB TAREA" name="name">
                            <button type="button" class="btn">&#10060;</button>
                            <button type="button" class="btn">&#9997;</button>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" value="<?php echo e($tarea->id); ?>" name="id">
                        <?php if($tarea->finished==0): ?>                    
                        <button type="submit" class="btn btn-sm btn-primary" name="opcion" value="1">COMPLETADA</button>
                        <button type="submit" class="btn btn-sm btn-light" data-dismiss="modal" name="opcion" value="2">EDITAR</button>
                        <button type="submit" class="btn btn-sm btn-secondary" data-dismiss="modal" name="opcion" value="3">ELIMINAR</button>
                        <?php else: ?>
                        <button type="submit" class="btn btn-sm btn-secondary" data-dismiss="modal" name="opcion" value="3">ELIMINAR</button>
                        <?php endif; ?>
                    </div>
                </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\testGeckode\resources\views/inicio.blade.php ENDPATH**/ ?>