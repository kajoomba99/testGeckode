<!DOCTYPE html>
<html>
<head>
    <title>TEST GECKODE</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
<a href="<?php echo e(route('inicio')); ?>" class="navbar-brand">TEST GECKODE</a>
</nav>
   <?php echo $__env->yieldContent('content'); ?>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\testGeckode\resources\views/layout.blade.php ENDPATH**/ ?>