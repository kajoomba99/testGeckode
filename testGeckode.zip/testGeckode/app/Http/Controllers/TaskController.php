<?php

namespace App\Http\Controllers;
use App\Models\Task;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    private $meses = ["ENE","FEB","MAR","ABR","MAY","JUN","JUL","AGO","SEP","OCT","NOV","DIC"];
    
    public function index(){
        $tareas = Task::all();
        // $resultado = substr($tareas[0]->created, 3, 2);
        // $index = (int)$resultado;
        // return $arreglo[$index];
        return view('inicio',[
            'tareas' => $tareas,
            'meses' => $this->meses
        ]);
    }
    public function add(Request $req){
        $insert = Task::insert([
            'name' => $req->task,
            'finished' => 0,
            'created' => date('d/m-Y')
        ]);
        $tareas = Task::all();
        return view('inicio',[
            'confirmacion' => $insert,
            'tareas' => $tareas,
            'meses' => $this->meses
        ]);
    }

    public function actions(Request $req){
        if($req->opcion == 1 ){
            Task::where('id',$req->id)->update([
                'finished'=> 1
            ]);
        }elseif ($req->opcion == 2) {
            Task::where('id',$req->id)->update([
                'name'=> $req->name
            ]);
        }elseif ($req->opcion == 3) {
            Task::where('id',$req->id)->delete();
        }
        $tareas = Task::all();
        // return $tareas;
        return view('inicio',[
            'tareas' => $tareas,
            'meses' => $this->meses
        ]);
    }
}
